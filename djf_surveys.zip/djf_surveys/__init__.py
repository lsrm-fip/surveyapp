__title__ = 'Django Form Surveys'
__version__ = '2.0.1'
__author__ = 'irfanpule'
